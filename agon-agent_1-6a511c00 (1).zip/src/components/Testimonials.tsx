import { Quote, Star } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { TESTIMONIALS } from '../data/testimonials';

function initials(name: string): string {
  return name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
}

export default function Testimonials() {
  return (
    <section id="reviews" className="py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Reviews"
          title="Loved by 12,400+ households and teams"
          description="4.8 out of 5 across more than 1,200 verified reviews. Here is what a few of them say."
        />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure key={t.name} className="card flex flex-col gap-4 p-6">
              <Quote className="h-6 w-6 text-brand-500/60" />
              <div className="flex gap-1" aria-label={`${t.rating} out of 5 stars`}>
                {Array.from({ length: 5 }, (_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < t.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                    }`}
                  />
                ))}
              </div>
              <blockquote className="flex-1 text-sm leading-relaxed text-slate-300">
                “{t.quote}”
              </blockquote>
              <figcaption className="flex items-center gap-3 border-t border-white/5 pt-4">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-500/30 to-violet-500/30 font-display text-sm font-bold text-white">
                  {initials(t.name)}
                </span>
                <div>
                  <p className="text-sm font-semibold text-white">{t.name}</p>
                  <p className="text-xs text-slate-500">
                    {t.area} · {t.plan}
                  </p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Activity, Headphones, MapPin, Users } from 'lucide-react';

const STATS = [
  { icon: Users, value: '12,400+', label: 'Homes & businesses connected' },
  { icon: Activity, value: '99.95%', label: 'Average network uptime' },
  { icon: MapPin, value: '38', label: 'Areas covered & counting' },
  { icon: Headphones, value: '24/7', label: 'Local human support' },
];

export default function Stats() {
  return (
    <section className="border-y border-white/5 bg-night-900/40">
      <div className="mx-auto grid w-full max-w-shell grid-cols-2 gap-8 px-4 py-12 sm:px-6 lg:grid-cols-4 lg:px-8">
        {STATS.map((stat) => (
          <div key={stat.label} className="flex flex-col items-center gap-2 text-center">
            <stat.icon className="h-6 w-6 text-brand-400" />
            <p className="font-display text-3xl font-extrabold text-white">{stat.value}</p>
            <p className="text-sm text-slate-400">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

import { useState, type FormEvent } from 'react';
import { CheckCircle2, Clock, Loader2, Mail, MapPin, Phone, Send } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { SITE } from '../config/site';
import { PLANS } from '../data/plans';

interface FormState {
  name: string;
  phone: string;
  email: string;
  area: string;
  planId: string;
  message: string;
}

type FormErrors = Partial<Record<keyof FormState, string>>;

const EMPTY_FORM: FormState = {
  name: '',
  phone: '',
  email: '',
  area: '',
  planId: 'home-family',
  message: '',
};

const INFO_CARDS = [
  { icon: Phone, label: 'Call or WhatsApp', value: SITE.phone, href: SITE.phoneHref },
  { icon: Mail, label: 'Email us', value: SITE.email, href: `mailto:${SITE.email}` },
  { icon: MapPin, label: 'Visit us', value: SITE.address },
  { icon: Clock, label: 'Opening hours', value: `${SITE.hours} · ${SITE.supportHours}` },
];

function validate(form: FormState): FormErrors {
  const errors: FormErrors = {};
  if (form.name.trim().length < 2) errors.name = 'Please enter your full name.';
  if (!/^[+0-9][0-9\s-]{8,15}$/.test(form.phone.trim()))
    errors.phone = 'Enter a valid phone number (e.g. 0711 456 789).';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()))
    errors.email = 'Enter a valid email address.';
  if (form.area.trim().length < 2) errors.area = 'Tell us your estate or area.';
  return errors;
}

function persistEnquiry(form: FormState) {
  try {
    const key = 'jikira_enquiries';
    const existing: unknown = JSON.parse(localStorage.getItem(key) ?? '[]');
    const list = Array.isArray(existing) ? existing : [];
    list.push({ ...form, submittedAt: new Date().toISOString() });
    localStorage.setItem(key, JSON.stringify(list));
  } catch {
    // Storage unavailable (private mode, etc.) — the confirmation shown to the
    // user still stands; a CRM integration will replace this store.
  }
}

export default function Contact() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const update = (field: keyof FormState, value: string) => {
    setForm((f) => ({ ...f, [field]: value }));
    setErrors((e) => ({ ...e, [field]: undefined }));
  };

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    const found = validate(form);
    setErrors(found);
    if (Object.values(found).some(Boolean)) return;

    setSubmitting(true);
    // Simulated submit latency; swap with a real API/CRM call when available.
    window.setTimeout(() => {
      persistEnquiry(form);
      setSubmitting(false);
      setSubmitted(true);
    }, 900);
  };

  const inputClasses = (hasError?: string) =>
    `w-full rounded-xl border bg-night-950/80 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 ${
      hasError
        ? 'border-rose-500/60 focus:border-rose-400 focus:ring-rose-500/30'
        : 'border-white/10 focus:border-brand-400/60 focus:ring-brand-500/30'
    }`;

  return (
    <section id="contact" className="py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Get connected"
          title="Talk to a human today, online this week"
          description="Leave your details and our team will call you back within one working hour to confirm coverage and book your installation."
        />

        <div className="mx-auto grid w-full max-w-5xl gap-6 lg:grid-cols-[1fr_1.3fr]">
          <div className="flex flex-col gap-4">
            {INFO_CARDS.map((card) => {
              const body = (
                <>
                  <span className="inline-grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-brand-500/15 text-brand-300">
                    <card.icon className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-xs font-semibold uppercase tracking-widest text-slate-500">
                      {card.label}
                    </span>
                    <span className="mt-1 block text-sm font-semibold text-white">{card.value}</span>
                  </span>
                </>
              );
              return card.href ? (
                <a
                  key={card.label}
                  href={card.href}
                  className="card flex items-center gap-4 p-5 transition-colors hover:border-brand-500/40"
                >
                  {body}
                </a>
              ) : (
                <div key={card.label} className="card flex items-center gap-4 p-5">
                  {body}
                </div>
              );
            })}
            <div className="card border-brand-500/30 bg-gradient-to-br from-brand-500/10 to-violet-500/10 p-5">
              <p className="font-display text-sm font-semibold text-white">Prefer M-Pesa?</p>
              <p className="mt-1 text-sm text-slate-400">
                Paybill{' '}
                <span className="font-mono font-semibold text-brand-300">{SITE.paybill}</span> —
                account number is your phone number. Activation is automatic within minutes.
              </p>
            </div>
          </div>

          <div className="card p-7 sm:p-9">
            {submitted ? (
              <div className="flex h-full flex-col items-center justify-center gap-4 py-10 text-center">
                <CheckCircle2 className="h-14 w-14 text-emerald-400" />
                <h3 className="font-display text-2xl font-bold text-white">
                  Request received, {form.name.split(' ')[0]}.
                </h3>
                <p className="max-w-sm text-sm leading-relaxed text-slate-400">
                  Our team will call <span className="text-slate-200">{form.phone}</span> within
                  one working hour to confirm coverage in{' '}
                  <span className="text-slate-200">{form.area}</span> and book your installation
                  slot.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setForm(EMPTY_FORM);
                    setSubmitted(false);
                  }}
                  className="mt-2 rounded-full border border-white/15 bg-white/5 px-6 py-2.5 text-sm font-semibold text-slate-100 transition-colors hover:border-brand-400/50 hover:text-brand-300"
                >
                  Submit another request
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-slate-400">
                      Full name
                    </label>
                    <input
                      id="name"
                      type="text"
                      value={form.name}
                      onChange={(e) => update('name', e.target.value)}
                      placeholder="Jane Wanjiku"
                      className={inputClasses(errors.name)}
                    />
                    {errors.name && <p className="mt-1.5 text-xs text-rose-400">{errors.name}</p>}
                  </div>
                  <div>
                    <label htmlFor="phone" className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-slate-400">
                      Phone / WhatsApp
                    </label>
                    <input
                      id="phone"
                      type="tel"
                      value={form.phone}
                      onChange={(e) => update('phone', e.target.value)}
                      placeholder="0711 456 789"
                      className={inputClasses(errors.phone)}
                    />
                    {errors.phone && <p className="mt-1.5 text-xs text-rose-400">{errors.phone}</p>}
                  </div>
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label htmlFor="email" className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-slate-400">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={(e) => update('email', e.target.value)}
                      placeholder="jane@example.com"
                      className={inputClasses(errors.email)}
                    />
                    {errors.email && <p className="mt-1.5 text-xs text-rose-400">{errors.email}</p>}
                  </div>
                  <div>
                    <label htmlFor="area" className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-slate-400">
                      Estate / area
                    </label>
                    <input
                      id="area"
                      type="text"
                      value={form.area}
                      onChange={(e) => update('area', e.target.value)}
                      placeholder="Kilimani"
                      className={inputClasses(errors.area)}
                    />
                    {errors.area && <p className="mt-1.5 text-xs text-rose-400">{errors.area}</p>}
                  </div>
                </div>

                <div>
                  <label htmlFor="plan" className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-slate-400">
                    Plan you are eyeing
                  </label>
                  <select
                    id="plan"
                    value={form.planId}
                    onChange={(e) => update('planId', e.target.value)}
                    className={inputClasses()}
                  >
                    {PLANS.map((plan) => (
                      <option key={plan.id} value={plan.id} className="bg-night-950">
                        {plan.name} — {plan.speedMbps} Mbps
                      </option>
                    ))}
                    <option value="unsure" className="bg-night-950">
                      Not sure yet — help me choose
                    </option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-slate-400">
                    Anything we should know? <span className="normal-case text-slate-600">(optional)</span>
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    value={form.message}
                    onChange={(e) => update('message', e.target.value)}
                    placeholder="Apartment block, gate code, best time to call…"
                    className={`${inputClasses()} resize-none`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-500/25 transition-transform hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:scale-100"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Sending…
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Request a callback
                    </>
                  )}
                </button>

                <p className="text-center text-xs text-slate-500">
                  We only use your details to arrange your installation. No spam, ever.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

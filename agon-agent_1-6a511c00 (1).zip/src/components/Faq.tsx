import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { FAQS } from '../data/faqs';
import { SITE } from '../config/site';

export default function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="border-t border-white/5 bg-night-900/30 py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="FAQs"
          title="Answers, before you even ask"
          description="The questions we hear most often, answered straight. Anything else — our team is one call away."
        />

        <div className="mx-auto w-full max-w-3xl space-y-3">
          {FAQS.map((item, index) => {
            const open = openIndex === index;
            return (
              <div key={item.question} className="card overflow-hidden">
                <button
                  type="button"
                  aria-expanded={open}
                  onClick={() => setOpenIndex(open ? null : index)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                >
                  <span className="font-display text-sm font-semibold text-white sm:text-base">
                    {item.question}
                  </span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-brand-400 transition-transform duration-300 ${
                      open ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {open && (
                  <p className="border-t border-white/5 px-6 py-5 text-sm leading-relaxed text-slate-400">
                    {item.answer}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        <p className="text-center text-sm text-slate-400">
          Still curious?{' '}
          <a href={SITE.phoneHref} className="font-semibold text-brand-300 hover:text-brand-200">
            Call {SITE.phone}
          </a>{' '}
          — a real person, any hour.
        </p>
      </div>
    </section>
  );
}

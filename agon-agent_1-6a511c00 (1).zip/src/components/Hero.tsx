import { ArrowRight, Gauge, MapPin, Sparkles, Wifi } from 'lucide-react';
import { SITE } from '../config/site';

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden pb-20 pt-32 sm:pt-36">
      {/* Ambient background glows */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 left-1/2 h-[34rem] w-[54rem] -translate-x-1/2 rounded-full bg-brand-500/15 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-40 top-40 h-96 w-96 rounded-full bg-violet-500/15 blur-3xl"
      />

      <div className="relative mx-auto grid w-full max-w-shell items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div className="flex flex-col items-start gap-6">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-semibold text-slate-200">
            <Sparkles className="h-3.5 w-3.5 text-brand-300" />
            Fibre + Fixed Wireless · Greater Nairobi
          </span>

          <h1 className="font-display text-4xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl">
            Internet that
            <span className="text-gradient"> just works</span>, everywhere you do.
          </h1>

          <p className="max-w-xl text-lg leading-relaxed text-slate-400">
            {SITE.name} delivers truly unlimited fibre and fixed-wireless broadband to
            homes and businesses — installed in days, backed by a 24/7 local team that
            actually picks up the phone.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <a
              href="#plans"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-500/30 transition-transform hover:scale-105"
            >
              View Plans
              <ArrowRight className="h-4 w-4" />
            </a>
            <a
              href="#coverage"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-7 py-3.5 text-sm font-semibold text-slate-100 transition-colors hover:border-brand-400/50 hover:text-brand-300"
            >
              <MapPin className="h-4 w-4" />
              Check Coverage
            </a>
          </div>

          <dl className="mt-2 flex flex-wrap gap-x-8 gap-y-3 text-sm text-slate-400">
            <div>
              <dt className="sr-only">Average install time</dt>
              <dd>
                <span className="font-semibold text-white">24–72h</span> installation
              </dd>
            </div>
            <div>
              <dt className="sr-only">Uptime</dt>
              <dd>
                <span className="font-semibold text-white">99.95%</span> network uptime
              </dd>
            </div>
            <div>
              <dt className="sr-only">Support</dt>
              <dd>
                <span className="font-semibold text-white">24/7</span> human support
              </dd>
            </div>
          </dl>
        </div>

        {/* Live-connection visual card */}
        <div className="relative">
          <div className="card relative overflow-hidden p-6 shadow-2xl shadow-black/40 sm:p-8">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="relative grid h-12 w-12 place-items-center rounded-2xl bg-brand-500/15 text-brand-300">
                  <span className="animate-ping-ring absolute inset-0 rounded-2xl border border-brand-400/40" />
                  <Wifi className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-display text-sm font-semibold text-white">
                    Home Gold · 50 Mbps
                  </p>
                  <p className="text-xs text-slate-400">Kilimani · connected 43 days</p>
                </div>
              </div>
              <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-300 ring-1 ring-inset ring-emerald-500/30">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                Online
              </span>
            </div>

            <div className="mt-7 grid grid-cols-3 gap-3 text-center">
              {[
                { label: 'Download', value: '49.8', unit: 'Mbps' },
                { label: 'Upload', value: '48.1', unit: 'Mbps' },
                { label: 'Ping', value: '7', unit: 'ms' },
              ].map((m) => (
                <div key={m.label} className="rounded-xl border border-white/5 bg-night-950/70 px-2 py-4">
                  <p className="font-display text-xl font-bold text-white">
                    {m.value}
                    <span className="ml-1 text-xs font-medium text-slate-400">{m.unit}</span>
                  </p>
                  <p className="mt-1 text-xs text-slate-400">{m.label}</p>
                </div>
              ))}
            </div>

            <div className="mt-7 space-y-3">
              {[
                { label: '4K stream', width: 'w-[86%]' },
                { label: 'Video calls', width: 'w-[64%]' },
                { label: 'Cloud backup', width: 'w-[93%]' },
              ].map((row) => (
                <div key={row.label}>
                  <div className="mb-1.5 flex justify-between text-xs text-slate-400">
                    <span>{row.label}</span>
                    <span className="text-brand-300">stable</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-white/5">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r from-brand-500 to-violet-500 ${row.width}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="animate-float absolute -right-3 -top-5 hidden items-center gap-2 rounded-2xl border border-white/10 bg-night-900/90 px-4 py-3 shadow-xl backdrop-blur sm:flex">
            <Gauge className="h-5 w-5 text-brand-300" />
            <div className="text-xs">
              <p className="font-semibold text-white">99.95% uptime</p>
              <p className="text-slate-400">last 90 days</p>
            </div>
          </div>

          <div className="animate-float-slow absolute -bottom-6 -left-4 hidden items-center gap-2 rounded-2xl border border-white/10 bg-night-900/90 px-4 py-3 shadow-xl backdrop-blur sm:flex">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-violet-500/20 text-violet-300">
              <Wifi className="h-4 w-4" />
            </span>
            <div className="text-xs">
              <p className="font-semibold text-white">38 areas served</p>
              <p className="text-slate-400">and expanding weekly</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { Menu, Phone, X } from 'lucide-react';
import { SITE } from '../config/site';

const NAV_LINKS = [
  { label: 'Plans', href: '#plans' },
  { label: 'Speed Test', href: '#speed' },
  { label: 'Coverage', href: '#coverage' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'FAQs', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open
          ? 'border-b border-white/10 bg-night-950/85 backdrop-blur-lg'
          : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto flex h-16 w-full max-w-shell items-center justify-between px-4 sm:px-6 lg:px-8">
        <a href="#home" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <img src="/logo.svg" alt="Jikira Broadband logo" className="h-9 w-9" />
          <span className="font-display text-lg font-bold tracking-tight text-white">
            Jikira<span className="text-brand-400"> Broadband</span>
          </span>
        </a>

        <ul className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm font-medium text-slate-300 transition-colors hover:text-brand-300"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={SITE.phoneHref}
            className="inline-flex items-center gap-2 text-sm font-semibold text-slate-200 transition-colors hover:text-brand-300"
          >
            <Phone className="h-4 w-4" />
            {SITE.phone}
          </a>
          <a
            href="#contact"
            className="rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-brand-500/25 transition-transform hover:scale-105"
          >
            Get Connected
          </a>
        </div>

        <button
          type="button"
          className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 text-slate-200 lg:hidden"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-night-950/95 px-4 pb-6 pt-2 backdrop-blur-lg lg:hidden">
          <ul className="space-y-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="block rounded-lg px-3 py-2.5 text-base font-medium text-slate-200 transition-colors hover:bg-white/5 hover:text-brand-300"
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="mt-4 block rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-5 py-3 text-center text-sm font-semibold text-white"
          >
            Get Connected
          </a>
        </div>
      )}
    </header>
  );
}

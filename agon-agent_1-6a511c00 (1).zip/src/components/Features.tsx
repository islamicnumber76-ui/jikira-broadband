import { Headphones, Infinity as InfinityIcon, Router, ShieldCheck, Wrench, Zap } from 'lucide-react';
import SectionHeading from './SectionHeading';

const FEATURES = [
  {
    icon: Zap,
    title: 'Gigabit-capable fibre',
    text: 'A modern GPON fibre network with headroom to spare — what you buy is what you get, even at 8pm.',
  },
  {
    icon: InfinityIcon,
    title: 'Truly unlimited data',
    text: 'No caps, no shaping, no “fair usage” small print. Stream, back up and download as much as you like.',
  },
  {
    icon: Headphones,
    title: '24/7 local support',
    text: 'Our Nairobi-based team answers in minutes by phone, WhatsApp or chat — no ticket black holes.',
  },
  {
    icon: Wrench,
    title: 'Fast, free installation',
    text: 'Free standard installation on most plans, scheduled within 24–72 hours by our own in-house crews.',
  },
  {
    icon: Router,
    title: 'Wi-Fi that reaches',
    text: 'Free Wi-Fi 6 routers and optional mesh kits, tuned on-site so every room — not just the router room — flies.',
  },
  {
    icon: ShieldCheck,
    title: 'Secure by default',
    text: 'Encrypted backhaul, WPA3-ready hardware and optional static IPs and content filtering for families.',
  },
];

export default function Features() {
  return (
    <section id="features" className="py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Why Jikira"
          title="Built for people who are tired of buffering"
          description="We run our own last-mile network and our own support team, so nothing about your connection is someone else's problem."
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature) => (
            <article
              key={feature.title}
              className="card group p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand-500/40"
            >
              <span className="mb-4 inline-grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-500/20 to-violet-500/20 text-brand-300 transition-colors group-hover:text-brand-200">
                <feature.icon className="h-6 w-6" />
              </span>
              <h3 className="font-display text-lg font-semibold text-white">{feature.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{feature.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

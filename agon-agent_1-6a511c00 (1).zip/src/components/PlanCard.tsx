import { ArrowRight, Check } from 'lucide-react';
import type { Plan } from '../data/plans';
import { formatKes } from '../lib/format';

interface PlanCardProps {
  plan: Plan;
}

export default function PlanCard({ plan }: PlanCardProps) {
  return (
    <article
      className={`card relative flex flex-col p-7 transition-all duration-300 hover:-translate-y-1.5 ${
        plan.popular
          ? 'border-brand-500/50 shadow-xl shadow-brand-500/10'
          : 'hover:border-white/20'
      }`}
    >
      {plan.popular && (
        <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-4 py-1 text-xs font-bold uppercase tracking-wide text-white shadow-lg">
          Most popular
        </span>
      )}

      <header className="mb-5">
        <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
          {plan.category === 'home' ? 'Home' : 'Business'}
        </p>
        <h3 className="mt-1 font-display text-xl font-bold text-white">{plan.name}</h3>
        <p className="mt-2 min-h-10 text-sm text-slate-400">{plan.tagline}</p>
      </header>

      <div className="mb-6 flex items-end justify-between border-b border-white/5 pb-6">
        <p>
          <span className="font-display text-4xl font-extrabold text-white">{plan.speedMbps}</span>
          <span className="ml-1 text-sm font-medium text-slate-400">Mbps</span>
        </p>
        <p className="text-right">
          <span className="font-display text-lg font-bold text-brand-300">
            {formatKes(plan.priceKes)}
          </span>
          <span className="block text-xs text-slate-500">per month, incl. VAT</span>
        </p>
      </div>

      <ul className="mb-7 flex flex-1 flex-col gap-2.5">
        {plan.features.map((feature) => (
          <li key={feature} className="flex items-start gap-2.5 text-sm text-slate-300">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <a
        href={`#contact`}
        className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-transform hover:scale-[1.03] ${
          plan.popular
            ? 'bg-gradient-to-r from-brand-500 to-violet-500 text-white shadow-lg shadow-brand-500/25'
            : 'border border-white/15 bg-white/5 text-slate-100 hover:border-brand-400/50 hover:text-brand-300'
        }`}
      >
        Get {plan.name}
        <ArrowRight className="h-4 w-4" />
      </a>
    </article>
  );
}

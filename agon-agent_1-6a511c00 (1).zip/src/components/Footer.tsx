import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, Twitter } from 'lucide-react';
import { SITE } from '../config/site';
import { HOME_PLANS, BUSINESS_PLANS } from '../data/plans';

const SOCIALS = [
  { icon: Facebook, href: SITE.socials.facebook, label: 'Facebook' },
  { icon: Twitter, href: SITE.socials.twitter, label: 'X (Twitter)' },
  { icon: Instagram, href: SITE.socials.instagram, label: 'Instagram' },
  { icon: Linkedin, href: SITE.socials.linkedin, label: 'LinkedIn' },
];

const QUICK_LINKS = [
  { label: 'Plans & pricing', href: '#plans' },
  { label: 'Speed estimator', href: '#speed' },
  { label: 'Coverage checker', href: '#coverage' },
  { label: 'Customer reviews', href: '#reviews' },
  { label: 'FAQs', href: '#faq' },
  { label: 'Get connected', href: '#contact' },
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-white/5 bg-night-900/40">
      <div className="mx-auto w-full max-w-shell px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div className="flex flex-col gap-4">
            <a href="#home" className="flex items-center gap-2.5">
              <img src="/logo.svg" alt="Jikira Broadband logo" className="h-9 w-9" />
              <span className="font-display text-lg font-bold tracking-tight text-white">
                Jikira<span className="text-brand-400"> Broadband</span>
              </span>
            </a>
            <p className="max-w-xs text-sm leading-relaxed text-slate-400">
              {SITE.description}
            </p>
            <div className="flex gap-3">
              {SOCIALS.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={social.label}
                  className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-slate-400 transition-colors hover:border-brand-400/50 hover:text-brand-300"
                >
                  <social.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <nav aria-label="Quick links">
            <h3 className="mb-4 font-display text-sm font-semibold uppercase tracking-widest text-white">
              Explore
            </h3>
            <ul className="space-y-2.5 text-sm">
              {QUICK_LINKS.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-slate-400 transition-colors hover:text-brand-300">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Popular plans">
            <h3 className="mb-4 font-display text-sm font-semibold uppercase tracking-widest text-white">
              Popular plans
            </h3>
            <ul className="space-y-2.5 text-sm">
              {[...HOME_PLANS.slice(0, 3), ...BUSINESS_PLANS.slice(0, 2)].map((plan) => (
                <li key={plan.id}>
                  <a href="#plans" className="text-slate-400 transition-colors hover:text-brand-300">
                    {plan.name} · {plan.speedMbps} Mbps
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="mb-4 font-display text-sm font-semibold uppercase tracking-widest text-white">
              Contact
            </h3>
            <ul className="space-y-3 text-sm text-slate-400">
              <li className="flex items-start gap-2.5">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                <a href={SITE.phoneHref} className="transition-colors hover:text-brand-300">
                  {SITE.phone}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                <a href={`mailto:${SITE.email}`} className="transition-colors hover:text-brand-300">
                  {SITE.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                <span>{SITE.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-7 text-xs text-slate-500 sm:flex-row">
          <p>
            © {SITE.foundedYear}–{year} {SITE.name} Ltd. All rights reserved.
          </p>
          <p>
            M-Pesa Paybill{' '}
            <span className="font-mono text-slate-400">{SITE.paybill}</span> · Licensed by the CA,
            Kenya
          </p>
        </div>
      </div>
    </footer>
  );
}

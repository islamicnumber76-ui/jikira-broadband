import { useState } from 'react';
import SectionHeading from './SectionHeading';
import PlanCard from './PlanCard';
import { PLANS, type PlanCategory } from '../data/plans';

type Filter = 'all' | PlanCategory;

const TABS: { id: Filter; label: string }[] = [
  { id: 'all', label: 'All plans' },
  { id: 'home', label: 'For home' },
  { id: 'business', label: 'For business' },
];

export default function Plans() {
  const [filter, setFilter] = useState<Filter>('all');
  const visible = PLANS.filter((plan) => filter === 'all' || plan.category === filter);

  return (
    <section id="plans" className="border-t border-white/5 bg-night-900/30 py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Packages"
          title="Simple plans, honest prices"
          description="Every plan is unlimited with no contracts on home packages. Prices include VAT — the number you see is the bill you get."
        />

        <div className="flex justify-center">
          <div className="inline-flex rounded-full border border-white/10 bg-night-950/70 p-1">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`rounded-full px-5 py-2 text-sm font-semibold transition-all ${
                  filter === tab.id
                    ? 'bg-gradient-to-r from-brand-500 to-violet-500 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((plan) => (
            <PlanCard key={plan.id} plan={plan} />
          ))}
        </div>

        <p className="text-center text-sm text-slate-500">
          Need something bespoke — a gated community, an SACCO, a whole office park?{' '}
          <a href="#contact" className="font-semibold text-brand-300 hover:text-brand-200">
            Talk to us about custom circuits
          </a>
          .
        </p>
      </div>
    </section>
  );
}

import { useState, type FormEvent } from 'react';
import { CheckCircle2, Clock, MapPin, RadioTower, Search, XCircle } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { SITE } from '../config/site';
import {
  COVERAGE_AREAS,
  COVERAGE_STATUS_LABEL,
  findCoverage,
  type CoverageArea,
} from '../data/coverage';

const STATUS_DOT: Record<CoverageArea['status'], string> = {
  fiber: 'bg-brand-400',
  wireless: 'bg-violet-400',
  soon: 'bg-amber-400',
};

export default function CoverageChecker() {
  const [query, setQuery] = useState('');
  const [searched, setSearched] = useState(false);
  const [match, setMatch] = useState<CoverageArea | undefined>(undefined);

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    setMatch(findCoverage(query));
    setSearched(true);
  };

  return (
    <section id="coverage" className="border-t border-white/5 bg-night-900/30 py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Coverage"
          title="Are we on your street yet?"
          description="Type your estate or neighbourhood to see live availability. New areas light up every month — waitlist members get free installation on launch."
        />

        <div className="mx-auto w-full max-w-2xl">
          <form onSubmit={onSubmit} className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSearched(false);
                }}
                list="coverage-areas"
                placeholder="e.g. Kilimani, Ruaka, Kitengela…"
                className="w-full rounded-full border border-white/10 bg-night-950/80 py-3.5 pl-11 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-brand-400/60 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
              <datalist id="coverage-areas">
                {COVERAGE_AREAS.map((area) => (
                  <option key={area.name} value={area.name} />
                ))}
              </datalist>
            </div>
            <button
              type="submit"
              className="rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-brand-500/25 transition-transform hover:scale-105"
            >
              Check availability
            </button>
          </form>

          {searched && (
            <div className="card mt-5 flex items-start gap-4 p-6">
              {match ? (
                match.status === 'fiber' ? (
                  <>
                    <CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0 text-emerald-400" />
                    <div>
                      <p className="font-display font-semibold text-white">
                        Great news — fibre is live in {match.name}.
                      </p>
                      <p className="mt-1 text-sm text-slate-400">
                        We can usually install within 24–72 hours.{' '}
                        <a href="#plans" className="font-semibold text-brand-300 hover:text-brand-200">
                          Pick a plan
                        </a>{' '}
                        and you could be online this week.
                      </p>
                    </div>
                  </>
                ) : match.status === 'wireless' ? (
                  <>
                    <RadioTower className="mt-0.5 h-6 w-6 shrink-0 text-violet-300" />
                    <div>
                      <p className="font-display font-semibold text-white">
                        {match.name} is covered by our fixed-wireless network.
                      </p>
                      <p className="mt-1 text-sm text-slate-400">
                        Same-day installation with an outdoor receiver, up to 30 Mbps,
                        no trenching required. Fibre is on the roadmap for this area.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <Clock className="mt-0.5 h-6 w-6 shrink-0 text-amber-300" />
                    <div>
                      <p className="font-display font-semibold text-white">
                        {match.name} is coming soon.
                      </p>
                      <p className="mt-1 text-sm text-slate-400">
                        Join the waitlist and get free installation plus one month free
                        when we switch the area on.
                      </p>
                    </div>
                  </>
                )
              ) : (
                <>
                  <XCircle className="mt-0.5 h-6 w-6 shrink-0 text-rose-400" />
                  <div>
                    <p className="font-display font-semibold text-white">
                      We could not find “{query.trim()}” yet.
                    </p>
                    <p className="mt-1 text-sm text-slate-400">
                      Rollouts are demand-driven — call{' '}
                      <a href={SITE.phoneHref} className="font-semibold text-brand-300 hover:text-brand-200">
                        {SITE.phone}
                      </a>{' '}
                      or leave your details below and we will tell you the moment your
                      area goes live.
                    </p>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        <div className="mx-auto w-full max-w-4xl">
          <div className="mb-4 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-slate-400">
            {(Object.keys(COVERAGE_STATUS_LABEL) as CoverageArea['status'][]).map((status) => (
              <span key={status} className="inline-flex items-center gap-2">
                <span className={`h-2 w-2 rounded-full ${STATUS_DOT[status]}`} />
                {COVERAGE_STATUS_LABEL[status]}
              </span>
            ))}
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {COVERAGE_AREAS.map((area) => (
              <button
                key={area.name}
                type="button"
                onClick={() => {
                  setQuery(area.name);
                  setMatch(area);
                  setSearched(true);
                }}
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-night-950/60 px-3.5 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:border-brand-400/50 hover:text-brand-200"
              >
                <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[area.status]}`} />
                {area.name}
              </button>
            ))}
          </div>
          <p className="mt-6 flex items-center justify-center gap-2 text-center text-xs text-slate-500">
            <MapPin className="h-3.5 w-3.5" />
            Do not see your area? We expand by demand — get in touch and vote for your street.
          </p>
        </div>
      </div>
    </section>
  );
}

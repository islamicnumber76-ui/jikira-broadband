import { useEffect, useRef, useState } from 'react';
import { Gauge, Play, RotateCcw } from 'lucide-react';
import SectionHeading from './SectionHeading';
import { PLANS } from '../data/plans';
import { formatKes } from '../lib/format';

type Phase = 'idle' | 'running' | 'done';

const RADIUS = 70;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
const ARC = CIRCUMFERENCE * 0.75; // 270° gauge
const DURATION_MS = 2600;

function recommendPlan(mbps: number) {
  const sorted = [...PLANS].sort((a, b) => a.speedMbps - b.speedMbps);
  return sorted.find((p) => p.speedMbps >= mbps) ?? sorted[sorted.length - 1];
}

export default function SpeedEstimator() {
  const [phase, setPhase] = useState<Phase>('idle');
  const [mbps, setMbps] = useState(0);
  const [ping, setPing] = useState(0);
  const [jitter, setJitter] = useState(0);
  const rafRef = useRef<number | undefined>(undefined);

  useEffect(
    () => () => {
      if (rafRef.current !== undefined) cancelAnimationFrame(rafRef.current);
    },
    [],
  );

  const startTest = () => {
    if (phase === 'running') return;
    setPhase('running');
    setPing(0);
    setJitter(0);

    const target = 18 + Math.random() * 78; // simulated link: 18–96 Mbps
    const startedAt = performance.now();

    const tick = (now: number) => {
      const progress = Math.min(1, (now - startedAt) / DURATION_MS);
      const eased = 1 - Math.pow(2, -10 * progress); // easeOutExpo ramp
      const noise = progress < 1 ? 0.93 + Math.random() * 0.14 : 1;
      setMbps(target * eased * noise);

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        setMbps(target);
        setPing(Math.floor(6 + Math.random() * 16));
        setJitter(Math.floor(1 + Math.random() * 5));
        setPhase('done');
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  };

  const reset = () => {
    if (rafRef.current !== undefined) cancelAnimationFrame(rafRef.current);
    setPhase('idle');
    setMbps(0);
    setPing(0);
    setJitter(0);
  };

  const fraction = Math.min(mbps / 100, 1);
  const recommended = phase === 'done' ? recommendPlan(mbps) : undefined;

  return (
    <section id="speed" className="py-24">
      <div className="mx-auto flex w-full max-w-shell flex-col gap-12 px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Speed estimator"
          title="How fast is your connection — really?"
          description="Run our quick line estimator and we will match the result to the Jikira plan that fits. For a full diagnostic, book a free on-site survey."
        />

        <div className="mx-auto grid w-full max-w-3xl gap-6 lg:grid-cols-[1.2fr_1fr]">
          <div className="card flex flex-col items-center gap-6 p-8">
            <div className="relative">
              <svg width="220" height="220" viewBox="0 0 220 220" className="-rotate-[135deg]">
                <circle
                  cx="110"
                  cy="110"
                  r={RADIUS}
                  fill="none"
                  stroke="rgba(255,255,255,0.07)"
                  strokeWidth="14"
                  strokeLinecap="round"
                  strokeDasharray={`${ARC} ${CIRCUMFERENCE}`}
                />
                <circle
                  cx="110"
                  cy="110"
                  r={RADIUS}
                  fill="none"
                  stroke="url(#gaugeGradient)"
                  strokeWidth="14"
                  strokeLinecap="round"
                  strokeDasharray={`${ARC * fraction} ${CIRCUMFERENCE}`}
                  className="transition-[stroke-dasharray] duration-100"
                />
                <defs>
                  <linearGradient id="gaugeGradient" x1="0" y1="1" x2="1" y2="0">
                    <stop offset="0%" stopColor="#22d3ee" />
                    <stop offset="100%" stopColor="#a78bfa" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="font-display text-5xl font-extrabold tabular-nums text-white">
                  {phase === 'idle' ? '—' : mbps.toFixed(1)}
                </p>
                <p className="mt-1 text-sm text-slate-400">Mbps download</p>
              </div>
            </div>

            <div className="grid w-full grid-cols-2 gap-3 text-center">
              <div className="rounded-xl border border-white/5 bg-night-950/70 py-3">
                <p className="font-display text-lg font-bold text-white">
                  {phase === 'done' ? `${ping} ms` : '—'}
                </p>
                <p className="text-xs text-slate-400">Ping</p>
              </div>
              <div className="rounded-xl border border-white/5 bg-night-950/70 py-3">
                <p className="font-display text-lg font-bold text-white">
                  {phase === 'done' ? `${jitter} ms` : '—'}
                </p>
                <p className="text-xs text-slate-400">Jitter</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={startTest}
                disabled={phase === 'running'}
                className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-500 to-violet-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-brand-500/25 transition-transform hover:scale-105 disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:scale-100"
              >
                <Play className="h-4 w-4" />
                {phase === 'running' ? 'Measuring…' : phase === 'done' ? 'Test again' : 'Start test'}
              </button>
              {phase !== 'idle' && (
                <button
                  type="button"
                  onClick={reset}
                  className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-200 transition-colors hover:border-brand-400/50 hover:text-brand-300"
                >
                  <RotateCcw className="h-4 w-4" />
                  Reset
                </button>
              )}
            </div>

            <p className="text-center text-xs text-slate-500">
              This is an animated estimate for illustration. Visit us for a guaranteed,
              on-site line measurement.
            </p>
          </div>

          <div className="card flex flex-col justify-center gap-4 p-8">
            <span className="inline-grid h-11 w-11 place-items-center rounded-2xl bg-brand-500/15 text-brand-300">
              <Gauge className="h-5 w-5" />
            </span>
            {phase === 'done' && recommended ? (
              <>
                <h3 className="font-display text-xl font-bold text-white">
                  {recommended.name} {recommended.speedMbps} Mbps has you covered
                </h3>
                <p className="text-sm leading-relaxed text-slate-400">
                  At an estimated {mbps.toFixed(1)} Mbps you would sit comfortably on{' '}
                  <span className="text-slate-200">{recommended.name}</span> from{' '}
                  <span className="font-semibold text-brand-300">
                    {formatKes(recommended.priceKes)}/month
                  </span>
                  , with headroom for busy evenings.
                </p>
                <a
                  href="#plans"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-brand-300 transition-colors hover:text-brand-200"
                >
                  See {recommended.name} details
                </a>
              </>
            ) : (
              <>
                <h3 className="font-display text-xl font-bold text-white">
                  Your plan recommendation appears here
                </h3>
                <p className="text-sm leading-relaxed text-slate-400">
                  Run the estimator and we will point you to the smallest plan that keeps
                  your streams, calls and game updates smooth — no over-buying.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

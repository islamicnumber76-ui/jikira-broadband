export interface FaqItem {
  question: string;
  answer: string;
}

export const FAQS: FaqItem[] = [
  {
    question: 'How long does installation take?',
    answer:
      'In fibre-ready areas we install within 24–72 hours of your order, once a quick (free) site survey confirms the drop route. Fixed-wireless installations are typically same-day or next-day because no cabling is required. Home Gold and Platinum customers get priority scheduling.',
  },
  {
    question: 'Do I need to buy a router?',
    answer:
      'No. Home Family, Gold and Platinum plans include a free dual-band Wi-Fi 6 router (Platinum includes a mesh kit). On Home Start you can use your own router or buy one from us for KES 3,500. All routers we supply are pre-configured and securely locked to your account.',
  },
  {
    question: 'Is the data really unlimited?',
    answer:
      'Yes. There is no data cap and no fair-usage throttling on any of our plans. You pay for speed, not gigabytes, and we monitor capacity at the network level so peak-hour speeds stay consistent.',
  },
  {
    question: 'How do I pay my bill?',
    answer:
      'We accept M-Pesa (Paybill 880 456), all major cards and bank transfer. You can pay monthly in advance or enable auto-billing so you never get disconnected. Business customers can opt into invoiced billing with a 7-day window.',
  },
  {
    question: 'Can I upgrade or downgrade my plan?',
    answer:
      'Any time, from your customer portal or with one WhatsApp message. Upgrades apply within an hour; downgrades apply from the next billing cycle, and we prorate the difference — you never pay for speed you did not use.',
  },
  {
    question: 'What happens when there is an outage?',
    answer:
      'Our 24/7 network operations centre detects most faults before customers notice and we send proactive SMS updates. Business plans carry a 99.9–99.95% uptime SLA: if we miss it, service credits are applied automatically to your next invoice.',
  },
  {
    question: 'Is Jikira available in my area?',
    answer:
      'Use the coverage checker on this page — it covers every estate we serve with fibre, fixed-wireless or upcoming rollouts. If we are not there yet, join the waitlist: we prioritise new rollouts by demand, and waitlist members get free installation when we go live.',
  },
  {
    question: 'Am I locked into a contract?',
    answer:
      'Home plans are month-to-month with no lock-in. Business plans are also monthly, with an optional 12-month agreement that waives installation and hardware costs. Enterprise circuits are quoted with custom terms.',
  },
];

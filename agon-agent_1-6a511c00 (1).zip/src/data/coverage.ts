export type CoverageStatus = 'fiber' | 'wireless' | 'soon';

export interface CoverageArea {
  name: string;
  status: CoverageStatus;
}

export const COVERAGE_STATUS_LABEL: Record<CoverageStatus, string> = {
  fiber: 'Fibre available',
  wireless: 'Fixed-wireless available',
  soon: 'Coming soon',
};

/**
 * Areas currently served (or soon to be served) by Jikira Broadband.
 * The coverage checker performs a case-insensitive substring match against
 * the `name` field, so keep names in their most common spelling.
 */
export const COVERAGE_AREAS: CoverageArea[] = [
  { name: 'Kilimani', status: 'fiber' },
  { name: 'Kileleshwa', status: 'fiber' },
  { name: 'Westlands', status: 'fiber' },
  { name: 'Parklands', status: 'fiber' },
  { name: 'Lavington', status: 'fiber' },
  { name: 'Upper Hill', status: 'fiber' },
  { name: 'South B', status: 'fiber' },
  { name: 'South C', status: 'fiber' },
  { name: "Lang'ata", status: 'fiber' },
  { name: 'Karen', status: 'fiber' },
  { name: 'Runda', status: 'fiber' },
  { name: 'Gigiri', status: 'fiber' },
  { name: 'Ruaka', status: 'fiber' },
  { name: 'Roysambu', status: 'fiber' },
  { name: 'Kasarani', status: 'fiber' },
  { name: 'Donholm', status: 'fiber' },
  { name: 'Buruburu', status: 'fiber' },
  { name: 'Syokimau', status: 'fiber' },
  { name: 'Athi River', status: 'wireless' },
  { name: 'Kitengela', status: 'wireless' },
  { name: 'Ngong', status: 'wireless' },
  { name: 'Kikuyu', status: 'wireless' },
  { name: 'Kiambu', status: 'wireless' },
  { name: 'Ruiru', status: 'wireless' },
  { name: 'Juja', status: 'wireless' },
  { name: 'Thika', status: 'wireless' },
  { name: 'Kahawa', status: 'wireless' },
  { name: 'Zimmerman', status: 'wireless' },
  { name: 'Embakasi', status: 'soon' },
  { name: 'Umoja', status: 'soon' },
  { name: 'Eastleigh', status: 'soon' },
  { name: 'Ongata Rongai', status: 'soon' },
  { name: 'Machakos', status: 'soon' },
  { name: 'Nakuru', status: 'soon' },
];

/** Case-insensitive coverage lookup with two-way substring matching. */
export function findCoverage(query: string): CoverageArea | undefined {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return undefined;
  return COVERAGE_AREAS.find(
    (area) => area.name.toLowerCase().includes(q) || q.includes(area.name.toLowerCase()),
  );
}

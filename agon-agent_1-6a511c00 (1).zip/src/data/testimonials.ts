export interface Testimonial {
  name: string;
  area: string;
  plan: string;
  rating: number;
  quote: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Wanjiru Mwangi',
    area: 'Kilimani',
    plan: 'Home Family 25 Mbps',
    rating: 5,
    quote:
      'Switched from a bigger ISP and the difference is night and day. Netflix in 4K, two laptops on calls, zero buffering — and when I had a question at 9pm, a real human picked up.',
  },
  {
    name: 'Brian Otieno',
    area: 'Ruaka',
    plan: 'Home Gold 50 Mbps',
    rating: 5,
    quote:
      'I game competitively and stream at the same time. Ping to Nairobi servers is consistently under 10ms. Installation took less than a day from my first call.',
  },
  {
    name: 'Amina Hassan',
    area: 'South C',
    plan: 'Business Launch 50 Mbps',
    rating: 5,
    quote:
      'Our café runs card payments, CCTV and guest Wi-Fi on Jikira. In eight months we have had one short outage — and they texted us before we even noticed.',
  },
  {
    name: 'Kevin Njoroge',
    area: 'Syokimau',
    plan: 'Home Platinum 100 Mbps',
    rating: 4,
    quote:
      'I upload large video projects daily. The mesh kit they installed covers the whole house and speeds match what is advertised, even at peak hours.',
  },
  {
    name: 'Sarah Wambui',
    area: 'Kitengela',
    plan: 'Fixed Wireless 20 Mbps',
    rating: 4,
    quote:
      'Fibre has not reached us yet, but the wireless link has been rock solid through rain and shine. Online classes for the kids, no drama.',
  },
  {
    name: 'Daniel Kiptoo',
    area: 'Westlands',
    plan: 'Business Pro 100 Mbps',
    rating: 5,
    quote:
      'The SLA is real. A fibre cut on our street was fixed in under three hours and the account manager called us twice with updates. That is service.',
  },
];

export type PlanCategory = 'home' | 'business';

export interface Plan {
  id: string;
  name: string;
  category: PlanCategory;
  speedMbps: number;
  priceKes: number;
  tagline: string;
  popular?: boolean;
  features: string[];
}

export const PLANS: Plan[] = [
  {
    id: 'home-start',
    name: 'Home Start',
    category: 'home',
    speedMbps: 10,
    priceKes: 1799,
    tagline: 'Everyday browsing, email and socials for small households.',
    features: [
      'Unlimited data — no caps, no throttling',
      'HD streaming on 1–2 devices',
      'Free standard installation',
      'Wi-Fi router from KES 3,500 (or use your own)',
      'M-Pesa, card & bank payments',
    ],
  },
  {
    id: 'home-family',
    name: 'Home Family',
    category: 'home',
    speedMbps: 25,
    priceKes: 2999,
    tagline: 'Smooth streaming, school and work-from-home for the whole family.',
    popular: true,
    features: [
      'Unlimited data — no caps, no throttling',
      'Full-HD streaming on 3–5 devices',
      'Free dual-band Wi-Fi 6 router included',
      'Free standard installation',
      'Priority WhatsApp support',
    ],
  },
  {
    id: 'home-gold',
    name: 'Home Gold',
    category: 'home',
    speedMbps: 50,
    priceKes: 4499,
    tagline: '4K streaming, competitive gaming and busy smart homes.',
    features: [
      'Unlimited data — no caps, no throttling',
      '4K streaming on 6+ devices',
      'Free dual-band Wi-Fi 6 router included',
      'Free priority installation (within 48h)',
      'Free static IP on request',
    ],
  },
  {
    id: 'home-platinum',
    name: 'Home Platinum',
    category: 'home',
    speedMbps: 100,
    priceKes: 7999,
    tagline: 'Maximum headroom for creators, home offices and power users.',
    features: [
      'Unlimited data — no caps, no throttling',
      '8K-ready, heavy uploads & cloud backups',
      'Premium mesh Wi-Fi kit included',
      'Same-day installation where available',
      'Dedicated support line & static IP',
    ],
  },
  {
    id: 'biz-launch',
    name: 'Business Launch',
    category: 'business',
    speedMbps: 50,
    priceKes: 8999,
    tagline: 'Reliable fibre for shops, cafés and small offices up to 15 staff.',
    features: [
      'Unlimited business-grade fibre',
      '1 static IP address included',
      '99.9% uptime SLA with credits',
      'Business-hours on-site support',
      'Guest Wi-Fi portal included',
    ],
  },
  {
    id: 'biz-pro',
    name: 'Business Pro',
    category: 'business',
    speedMbps: 100,
    priceKes: 14999,
    tagline: 'For growing teams that live on video calls and cloud tools.',
    popular: true,
    features: [
      'Unlimited business-grade fibre',
      'Up to 4 static IP addresses',
      '99.95% uptime SLA with credits',
      '4-hour fault response, 24/7 NOC',
      'Optional LTE failover add-on',
    ],
  },
  {
    id: 'biz-enterprise',
    name: 'Enterprise Dedicated',
    category: 'business',
    speedMbps: 500,
    priceKes: 39999,
    tagline: 'Dedicated uncontended bandwidth for campuses and head offices.',
    features: [
      'Dedicated 1:1 uncontended circuit',
      'Scalable to 1 Gbps on demand',
      '99.95% SLA, 2-hour fault response',
      'BGP / IP transit options available',
      'Named account & service manager',
    ],
  },
];

/** All home-category plans, cheapest first. */
export const HOME_PLANS = PLANS.filter((p) => p.category === 'home');

/** All business-category plans, cheapest first. */
export const BUSINESS_PLANS = PLANS.filter((p) => p.category === 'business');

const env = import.meta.env;

/**
 * Central brand & contact configuration.
 * Values can be overridden through the optional environment variables
 * documented in `.env.example`.
 */
export const SITE = {
  name: 'Jikira Broadband',
  shortName: 'Jikira',
  tagline: 'Internet that just works.',
  description:
    'Fibre and fixed-wireless internet for homes and businesses across Nairobi and beyond — unlimited data, free installation and 24/7 local support.',
  phone: env.VITE_SUPPORT_PHONE || '+254 711 456 789',
  phoneHref: `tel:${(env.VITE_SUPPORT_PHONE || '+254711456789').replace(/[\s-]/g, '')}`,
  whatsappHref: 'https://wa.me/254711456789',
  email: env.VITE_CONTACT_EMAIL || 'hello@jikirabroadband.co.ke',
  supportEmail: 'support@jikirabroadband.co.ke',
  address: 'Jikira House, 4th Floor, Moi Avenue, Nairobi',
  hours: 'Mon–Sat: 8:00 AM – 6:00 PM',
  supportHours: 'Network support: 24/7, every day',
  paybill: '880 456',
  foundedYear: 2019,
  socials: {
    facebook: 'https://facebook.com/jikirabroadband',
    twitter: 'https://x.com/jikirabroadband',
    instagram: 'https://instagram.com/jikirabroadband',
    linkedin: 'https://linkedin.com/company/jikirabroadband',
  },
} as const;

export type Site = typeof SITE;

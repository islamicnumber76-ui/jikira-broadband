import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Stats from './components/Stats';
import Features from './components/Features';
import Plans from './components/Plans';
import SpeedEstimator from './components/SpeedEstimator';
import CoverageChecker from './components/CoverageChecker';
import Testimonials from './components/Testimonials';
import Faq from './components/Faq';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-night-950 font-body text-slate-300">
      <Navbar />
      <main>
        <Hero />
        <Stats />
        <Features />
        <Plans />
        <SpeedEstimator />
        <CoverageChecker />
        <Testimonials />
        <Faq />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

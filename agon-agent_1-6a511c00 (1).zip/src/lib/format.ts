const kesFormatter = new Intl.NumberFormat('en-KE', {
  style: 'currency',
  currency: 'KES',
  maximumFractionDigits: 0,
});

/** Format a number as Kenyan shillings, e.g. KES 2,999 */
export function formatKes(amount: number): string {
  return kesFormatter.format(amount);
}

/** Format a number with thousands separators, e.g. 12,400 */
export function formatCount(value: number): string {
  return new Intl.NumberFormat('en-KE').format(value);
}

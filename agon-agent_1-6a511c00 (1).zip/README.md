# Jikira Broadband

Marketing and self-service website for **Jikira Broadband**, a fibre-to-the-home (FTTH)
and fixed-wireless internet service provider. Built with Vite, React, TypeScript and
Tailwind CSS, and ready to deploy on Vercel.

## Features

- **Plan catalogue** — home & business packages with category filtering and
  Kenya-shilling pricing.
- **Coverage checker** — visitors can type their estate / area and instantly see
  whether fibre, fixed-wireless or upcoming coverage is available.
- **Speed estimator** — an animated, client-side speed-test simulation that
  recommends the most suitable plan for the measured result.
- **FAQ accordion, testimonials, stats and feature sections.**
- **Contact / sign-up form** with client-side validation; enquiries are persisted
  to `localStorage` so nothing is lost before a CRM is wired in.
- Fully responsive, dark UI with lucide icons and hand-crafted SVG brand assets —
  no binary image dependencies.

## Tech stack

| Layer       | Choice                          |
| ----------- | ------------------------------- |
| Framework   | React 18 + TypeScript (strict)  |
| Bundler     | Vite 5                          |
| Styling     | Tailwind CSS 3 + PostCSS        |
| Icons       | lucide-react                    |
| Hosting     | Vercel (`vercel.json` included) |

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Type-check + production build (outputs to dist/)
npm run build

# 4. Preview the production build locally
npm run preview
```

## Environment variables

All variables are optional — the site works with zero configuration. Copy
`.env.example` to `.env.local` to override the public contact details:

```bash
cp .env.example .env.local
```

| Variable             | Purpose                              |
| -------------------- | ------------------------------------ |
| `VITE_CONTACT_EMAIL` | Public email shown across the site   |
| `VITE_SUPPORT_PHONE` | Public phone number shown on site    |
| `VITE_ANALYTICS_ID`  | Reserved for a future analytics hook |

## Project structure

```
jikira-broadband/
├── index.html               # SPA entry, fonts & meta
├── public/                  # Static assets (favicon, logo, robots.txt)
├── src/
│   ├── main.tsx             # React bootstrap
│   ├── App.tsx              # Page composition
│   ├── index.css            # Tailwind layers + small keyframe utilities
│   ├── config/site.ts       # Central brand / contact configuration
│   ├── data/                # Plans, coverage areas, FAQs, testimonials
│   ├── lib/format.ts        # Currency & misc formatting helpers
│   └── components/          # Navbar, Hero, Plans, SpeedEstimator,
│                            # CoverageChecker, Testimonials, Faq,
│                            # Contact, Footer, ...
├── tailwind.config.js
├── vercel.json              # SPA rewrite + build settings for Vercel
└── vite.config.ts
```

## Deployment (Vercel)

The repository is deploy-ready: `vercel.json` pins the Vite framework preset and
adds an SPA fallback rewrite. Either import the repo in the Vercel dashboard or use
the CLI:

```bash
npx vercel        # first deploy (creates .vercel/, which is git-ignored)
npx vercel --prod # production deploy
```

## License

MIT — see [LICENSE](./LICENSE).

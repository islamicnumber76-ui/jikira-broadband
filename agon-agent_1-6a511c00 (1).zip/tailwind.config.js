/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#ecfeff',
          100: '#cffafe',
          200: '#a5f3fc',
          300: '#67e8f9',
          400: '#22d3ee',
          500: '#06b6d4',
          600: '#0891b2',
          700: '#0e7490',
          800: '#155e75',
          900: '#164e63',
          950: '#083344',
        },
        night: {
          50: '#f3f6fc',
          100: '#e5ebf7',
          200: '#c9d6ee',
          300: '#9db2dd',
          400: '#6b87c7',
          500: '#4a68ae',
          600: '#3a5292',
          700: '#304276',
          800: '#2b3a62',
          900: '#1b2540',
          950: '#0b1020',
        },
      },
      fontFamily: {
        display: ['Sora', 'Inter', 'system-ui', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      maxWidth: {
        shell: '80rem',
      },
    },
  },
  plugins: [],
};
